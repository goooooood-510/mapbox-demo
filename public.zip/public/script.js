// === ユーザー識別用の一意IDを生成 ===
const uid = crypto.randomUUID(); // ユーザーごとに固有のIDを割り当て
const markers = {}; // 他ユーザーのマーカーを保持

// === Mapbox初期化 ===
mapboxgl.accessToken = 'pk.eyJ1IjoiY29pbnB1a2V0IiwiYSI6ImNsbGprYTU4ZTBmYjQzcGs3eWN4dXRrN2QifQ.qM9dxYwR-Mciv2J7Rg7z2A';

const map = new mapboxgl.Map({
  container: 'map',
  style: 'mapbox://styles/mapbox/streets-v11',
  center: [139.7670, 35.6814], // 初期表示の座標（東京駅など）
  zoom: 14
});

// 自分の位置マーカー（青）
const marker = new mapboxgl.Marker({ color: 'blue' }).addTo(map);

// === WebSocket接続 ===
let socket = new WebSocket('ws://mapbox-demo.onrender.com');
let pendingData = null;
let watchId = null;

socket.onopen = () => {
  console.log('✅ WebSocket接続完了');

  // 保留データがあれば送信
  if (pendingData) {
    socket.send(JSON.stringify(pendingData));
    pendingData = null;
  }

  // 接続完了後に位置取得開始
  startGeolocation();
};

// === 自分の位置を取得し送信 ===
function startGeolocation() {
  if (watchId !== null) {
    navigator.geolocation.clearWatch(watchId); // 二重取得防止
  }

  watchId = navigator.geolocation.watchPosition(
    (position) => {
      const lat = position.coords.latitude;
      const lng = position.coords.longitude;
      const speed = position.coords.speed;

      const data = {
        command: 'update',
        uid: uid,
        location: [lat, lng, speed]
      };

      // サーバーに送信
      if (socket.readyState === WebSocket.OPEN) {
        socket.send(JSON.stringify(data));
      } else {
        pendingData = data;
        console.warn("WebSocket未接続。送信データを待機中。");
      }

      // 自分のピンを更新
      marker.setLngLat([lng, lat]);
    },
    (error) => {
      console.error('位置情報の取得に失敗しました:', error);
    },
    {
      enableHighAccuracy: true,
      maximumAge: 10000,
      timeout: 10000
    }
  );
}

// === 他ユーザーからの位置情報を受け取る処理 ===
socket.onmessage = (event) => {
  const data = JSON.parse(event.data);
  const uidFromServer = data.uid;
  const location = data.location;

  // 自分自身の情報なら無視
  if (uidFromServer === uid) return;

  const [lat, lng] = location;

  if (markers[uidFromServer]) {
    // すでに存在するマーカーの位置を更新
    markers[uidFromServer].setLngLat([lng, lat]);
  } else {
    // 新しいユーザーのマーカー（赤）を作成
    const newMarker = new mapboxgl.Marker({ color: 'red' })
      .setLngLat([lng, lat])
      .addTo(map);

    markers[uidFromServer] = newMarker;
  }
};
